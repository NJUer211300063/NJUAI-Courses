# -*-coding:utf-8 -*-
from random import random
import tkinter
import random
import tkinter.messagebox
from tkinter import *


class MyForm:
    BLACK = 0  # 黑棋人类玩家
    WHITE = 1  # 白棋AI

    def __init__(self):
        self.is_startgame = False  # 开始标志
        self.chess_len = 15
        self.is_draw = self.chess_len * self.chess_len  # 用来判断是否平局
        self.cur_palyer = None  # 当前棋子的颜色
        self.winner = None
        self.cur_chess1 = None
        self.cur_chess2 = None  # 指向最新一个棋子对象，用来悔棋
        self.color = ['black', 'white']
        self.time = 5
        self.cur_pos1 = [None, None]
        self.cur_pos2 = [None, None]
        self.chess_list = [[3 for i in range(self.chess_len)] for j in range(self.chess_len)]
        self.white_info = []
        self.black_info = []
        self.score_list = [7, 35, 800, 15000, 800000, 15, 400, 8000, 100000, 0]
        # --------------------------------------------------------------------------------
        self.root = tkinter.Tk()
        self.root.title("FIVE-CHESS BY ZYJ")
        self.root.geometry("670x480+100+100")
        self.cv = tkinter.Canvas(self.root, width=480, height=480, background="#DEB887")  # 画布
        self.cv.place(x=0, y=0)
        self.cv1 = tkinter.Canvas(self.root, width=670 - 480, height=480, background='WHITE')  # 画布1
        self.cv1.place(x=480, y=0)
        self.start_button = tkinter.Button(self.root, text="Start Game", font=("微软雅黑", 20), width=10,
                                           command=self.startgame, relief=RIDGE, background="#DEB887")  # 开始游戏按钮
        self.start_button.place(x=490, y=30)
        self.huiqi_button = tkinter.Button(self.root, text="Take Back", font=("微软雅黑", 20), width=10,
                                           command=self.huiqi, relief=RIDGE, background="#DEB887")  # 悔棋按钮
        self.huiqi_button.place(x=490, y=110)
        self.restart_button = tkinter.Button(self.root, text="Restart", font=("微软雅黑", 20), width=10,
                                             command=self.restart, relief=RIDGE, background="#DEB887")  # 重新开始按钮
        self.restart_button.place(x=490, y=190)
        self.create_map()
        self.root.mainloop()

    def create_map(self):
        """"绘制棋盘"""
        for num in range(1, self.chess_len + 1):
            self.cv.create_line(num * 30, 30, num * 30, 450, width=2)
        for num in range(1, self.chess_len + 1):
            self.cv.create_line(30, num * 30, 450, num * 30, width=2)
        # self.cv.create_rectangle(240-5,240-5,240+5,240+5,fill='black')
        for i in range(self.chess_len):
            w = tkinter.Label(self.root, text='%d' % i, bg="#DEB887")
            w.place(x=22 + i * 30, y=5)
        for i in range(self.chess_len):
            w = tkinter.Label(self.root, text='%d' % i, bg="#DEB887")
            w.place(x=5, y=22 + i * 30)

    def startgame(self):
        self.is_startgame = True
        self.cv.bind("<Button-1>", self.gaming)
        self.cur_palyer = MyForm.BLACK

    def restart(self):
        self.winner = None
        self.cur_palyer = MyForm.BLACK
        self.is_draw = self.chess_len * self.chess_len
        for i in range(len(self.chess_list)):
            for j in range(len(self.chess_list)):
                self.chess_list[i][j] = 3
        self.time = 5
        self.black_info = []
        self.white_info = []
        self.cv.delete("all")
        self.create_map()

    def huiqi(self):
        if self.time > 0 and self.cur_chess1 and self.cur_chess2:
            self.cv.delete(self.cur_chess1)
            self.cur_chess1 = None
            self.cv.delete(self.cur_chess2)
            self.cur_chess2 = None
            # print(self.cur_chess1, self.cur_chess2)
            self.chess_list[self.cur_pos1[0]][self.cur_pos1[1]] = 3
            self.chess_list[self.cur_pos2[0]][self.cur_pos2[1]] = 3
            self.black_info.pop()
            self.white_info.pop()
            self.is_draw += 2
            self.winner = None
            # self.cur_palyer = (self.cur_palyer + 1) % 2
            self.time -= 1
            tkinter.messagebox.showinfo("Tips:", "You have %d more chances to\n take back!" % self.time)
        elif self.time <= 0:
            tkinter.messagebox.showinfo("Tips", "You can't take back any more!")
        else:
            return

    def draw_chess(self, x, y):
        if self.chess_list[x // 30 - 1][y // 30 - 1] == 3:
            self.cur_pos1 = self.cur_pos2
            self.cur_pos2 = [x // 30 - 1, y // 30 - 1]
            self.cur_chess1 = self.cur_chess2
            self.cur_chess2 = self.cv.create_oval(x - 15, y - 15, x + 15, y + 15,
                                                  fill=self.color[self.cur_palyer])  # 在鼠标点击处下棋
            self.chess_list[x // 30 - 1][y // 30 - 1] = self.cur_palyer
            if self.cur_palyer == MyForm.BLACK:
                self.black_info.append([x // 30 - 1, y // 30 - 1])
            else:
                self.white_info.append([x // 30 - 1, y // 30 - 1])
            self.cur_palyer = (self.cur_palyer + 1) % 2  # 更新棋子颜色
            self.is_draw -= 1
            self.judge_winner(x // 30 - 1, y // 30 - 1)  # 判断是否有人已经胜利
        else:
            self.cur_palyer = (self.cur_palyer + 1) % 2

    def get_pos(self, x, y):
        if 30 <= x <= 30 * self.chess_len and 30 <= y <= 30 * self.chess_len:
            if x % 30 >= 15:
                x = x + 30 - (x % 30)
            else:
                x = x - (x % 30)
            if y % 30 >= 15:
                y = y + 30 - (y % 30)
            else:
                y = y - (y % 30)
            return x, y
        else:
            return None

    def gaming(self, event):
        if self.is_startgame and not self.winner and self.is_draw:
            x, y = self.get_pos(event.x, event.y)
            if self.chess_list[x // 30 - 1][y // 30 - 1] == 3:
                # x, y = self.get_pos(event.x, event.y)
                self.draw_chess(x, y)
                self.AI_play()
            else:
                return

    def judge_winner(self, xx, yy):
        if not self.is_draw:
            self.winner = 'None'
            tkinter.messagebox.showinfo("I LOVE IU", "Game over, the game has drawn!")
        count = 0
        for i in range(xx + 1, self.chess_len):
            if self.chess_list[i][yy] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        for i in range(xx, -1, -1):
            if self.chess_list[i][yy] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            self.winner = self.color[self.chess_list[xx][yy]]
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % self.color[self.chess_list[xx][yy]])
        count = 0
        for i in range(yy + 1, self.chess_len):
            if self.chess_list[xx][i] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        for i in range(yy, -1, -1):
            if self.chess_list[xx][i] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            self.winner = self.color[self.chess_list[xx][yy]]
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % self.color[self.chess_list[xx][yy]])
        count = 0
        for i, j in zip(range(xx, -1, -1), range(yy, -1, -1)):
            if self.chess_list[i][j] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        for i, j in zip(range(xx + 1, self.chess_len), range(yy + 1, self.chess_len)):
            if self.chess_list[i][j] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            self.winner = self.color[self.chess_list[xx][yy]]
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % self.color[self.chess_list[xx][yy]])
        count = 0
        for i, j in zip(range(xx, -1, -1), range(yy, self.chess_len)):
            if self.chess_list[i][j] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        for i, j in zip(range(xx + 1, self.chess_len), range(yy - 1, -1, -1)):
            # print(self.chess_list[i][j],self.chess_list[xx][yy])
            if self.chess_list[i][j] == self.chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            self.winner = self.color[self.chess_list[xx][yy]]
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % self.color[self.chess_list[xx][yy]])
        count = 0

    def AI_play(self):
        if not self.winner and self.is_draw and self.is_startgame:
            x, y = self.best_pos()
            self.draw_chess((x + 1) * 30, (y + 1) * 30)

    def pos_score(self, pos):
        cur_score = 0   # 空位的初始得分初始化为0
        x = pos[0]
        y = pos[1]
        black_num = 0
        white_num = 0
        for i in range(5):      # 水平方向
            for j in range(5):
                if [x - j + i, y] in self.black_info:    # self.black_info是一个二维矩阵，里面存的是黑棋的坐标
                    black_num += 1
                if [x - j + i, y] in self.white_info:
                    white_num += 1
            cur_score = cur_score + self.get_score(black_num, white_num)
            white_num = 0
            black_num = 0
        for i in range(5):     # 竖直方向
            for j in range(5):
                if [x, y - j + i] in self.black_info:
                    black_num += 1
                if [x, y - j + i] in self.white_info:
                    white_num += 1
            cur_score = cur_score + self.get_score(black_num, white_num)
            white_num = 0
            black_num = 0
        for i in range(5):   # 右斜(/)方向
            for j in range(5):
                if [x + j - i, y - j + i] in self.black_info:
                    black_num += 1
                if [x + j - i, y - j + i] in self.white_info:
                    white_num += 1
            cur_score = cur_score + self.get_score(black_num, white_num)
            white_num = 0
            black_num = 0
        for i in range(5):   # 左斜(\)方向
            for j in range(5):
                if [x - j + i, y - j + i] in self.black_info:
                    black_num += 1
                if [x - j + i, y - j + i] in self.white_info:
                    white_num += 1
            cur_score = cur_score + self.get_score(black_num, white_num)
            white_num = 0
            black_num = 0
        return cur_score

    def get_score(self, black_num, white_num):
        if not black_num and not white_num:
            return self.score_list[0]
        elif black_num and white_num:
            return self.score_list[9]
        else:
            if black_num != 0:
                return self.score_list[black_num + 4]
            if white_num != 0:
                return self.score_list[white_num]

    def best_pos(self):
        score_list = []
        for i in range(self.chess_len):
            for j in range(self.chess_len):
                if self.chess_list[i][j] == 3:
                    score_list.append([self.pos_score([i, j]), i, j])
        score_list.sort(reverse=True)
        if score_list[0][0] - score_list[2][0] <= 50:
            pos = random.randint(0, 2)
        elif score_list[0][0] - score_list[1][0] <= 100:
            pos = random.randint(0, 1)
        else:
            pos = 0
        return score_list[pos][1], score_list[pos][2]


def main():
    mygame = MyForm()


main()
