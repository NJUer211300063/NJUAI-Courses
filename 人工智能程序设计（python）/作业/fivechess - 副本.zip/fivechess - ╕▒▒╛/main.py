# -*-coding:utf-8 -*-
import os
import tkinter
import tkinter.messagebox
from tkinter import *

chess_color = 1  # 奇数代表黑，偶数代表白
chess_list = [[3 for i in range(17)] for j in range(17)]  # 用来记录棋盘信息的矩阵
logo_path = "resources" + os.sep + "iu_logo.ico"  # logo路径
COLOR_WINNER = ["Black", "While"]
time = 5  # 允许悔棋的次数
r1 = 0  # 指向棋子的对象
now_x, now_y = -1, -1  # 最新落下的棋子的坐标
flag_to_huiqi = 0  # 是否允许悔棋的标志


class MyForm:
    def __init__(self):
        self.root = tkinter.Tk()  
        self.root.title("FIVE-CHESS BY ZYJ")  
        self.root.geometry("700x510+100+100")  
        self.root.iconbitmap(logo_path)  # logo
        self.cv = tkinter.Canvas(self.root, width=510, height=510, background="#DEB887")  # 画布
        self.cv1 = tkinter.Canvas(self.root, width=190, height=510, background='WHITE')  # 画布1
        self.huiqi_button = tkinter.Button(self.root, text="Take Back", font=("微软雅黑", 20), width=10,
                                           command=self.huiqi, relief=RIDGE, background="#DEB887")  
        self.restart_button = tkinter.Button(self.root, text="Restart", font=("微软雅黑", 20), width=10,
                                             command=self.restart, relief=RIDGE, background="#DEB887")   
        self.start_button = tkinter.Button(self.root, text="Start Game", font=("微软雅黑", 20), width=10,
                                           command=self.startgame, relief=RIDGE, background="#DEB887")
        self.is_gaming_judge = 0
        self.create_map()
        self.cv.place(x=0, y=0)
        self.cv1.place(x=510, y=0)
        self.huiqi_button.place(x=520, y=110)
        self.restart_button.place(x=520, y=190)
        self.start_button.place(x=520, y=30)
        self.root.mainloop()  

    def create_map(self):
        """"绘制棋盘"""
        for num in range(1, 17):
            self.cv.create_line(num * 30, 30, num * 30, 480, width=2)
        for num in range(1, 17):
            self.cv.create_line(30, num * 30, 480, num * 30, width=2)

    def draw_chess(self, event):
        """"绘制棋子"""
        global chess_color, flag_to_huiqi
        if chess_color % 2 == 0:
            color = "black"
        else:
            color = "white"
        x, y = 0, 0
        if 30 <= event.x <= 480 and 30 <= event.y <= 480:
            if event.x % 30 >= 15:
                x = event.x + 30 - (event.x % 30)
            else:
                x = event.x - (event.x % 30)
            if event.y % 30 >= 15:
                y = event.y + 30 - (event.y % 30)
            else:
                y = event.y - (event.y % 30)
            x1, y1 = x - 15, y - 15
            x2, y2 = x + 15, y + 15
            if chess_list[x // 30 - 1][y // 30 - 1] == 3:
                global r1, now_y, now_x
                now_x, now_y = x // 30 - 1, y // 30 - 1
                r1 = self.cv.create_oval(x1, y1, x2, y2, fill=color)  # 在鼠标点击处下棋
                flag_to_huiqi = 1  # 允许悔棋
                chess_list[x // 30 - 1][y // 30 - 1] = chess_color % 2
                chess_color += 1  # 更新棋子颜色
                self.judge_winner(x // 30 - 1, y // 30 - 1)  # 判断是否有人已经胜利
            else:
                return 0
        else:
            return 0

    def judge_winner(self, xx, yy):
        count = 0
        for i in range(xx + 1, 17):
            if chess_list[i][yy] == chess_list[xx][yy]:
                count += 1
            else:
                break
        for i in range(xx, -1, -1):
            if chess_list[i][yy] == chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % COLOR_WINNER[chess_list[xx][yy]])
        count = 0
        for i in range(yy + 1, 17):
            if chess_list[xx][i] == chess_list[xx][yy]:
                count += 1
            else:
                break
        for i in range(yy, -1, -1):
            if chess_list[xx][i] == chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % COLOR_WINNER[chess_list[xx][yy]])
        count = 0
        for i, j in zip(range(xx, -1, -1), range(yy, -1, -1)):
            if chess_list[i][j] == chess_list[xx][yy]:
                count += 1
            else:
                break
        for i, j in zip(range(xx + 1, 17), range(yy + 1, 17)):
            if chess_list[i][j] == chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % COLOR_WINNER[chess_list[xx][yy]])
        count = 0
        for i, j in zip(range(xx, -1, -1), range(yy, 17)):
            if chess_list[i][j] == chess_list[xx][yy]:
                count += 1
            else:
                break
        for i, j in zip(range(xx + 1, 17), range(yy, -1, -1)):
            if chess_list[i][j] == chess_list[xx][yy]:
                count += 1
            else:
                break
        if count == 5:
            tkinter.messagebox.showinfo("I LOVE IU", "Game over,winner is %s!" % COLOR_WINNER[chess_list[xx][yy]])
        count = 0

    def huiqi(self):
        global r1, time, chess_color
        if time > 0 and flag_to_huiqi == 1:
            self.cv.delete(r1)
            chess_list[now_x][now_y] = 3
            chess_color += 1
            time -= 1
            tkinter.messagebox.showinfo("Tips:", "You have %d more chances to\n take back!" % time)
            self.draw_chess()
        elif time <= 0:
            tkinter.messagebox.showinfo("Tips", "You can't take back any more!")
            self.draw_chess()

    def restart(self):
        global time, chess_color
        chess_color = 1
        for i in range(len(chess_list)):
            for j in range(len(chess_list)):
                chess_list[i][j] = 3
        time = 5
        self.cv.delete("all")
        self.create_map()

    def startgame(self):
        """判断游戏是否开始。开始了才可以画棋子"""                   
        self.is_gaming_judge += 1
        if self.is_gaming_judge:
            self.cv.bind("<Button-1>", self.draw_chess)


def main():
    MyForm()


if __name__ == "__main__":
    main()
